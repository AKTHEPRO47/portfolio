# Quick Start Guide

## ✅ Your Flask Portfolio is Ready!

The application is currently running at: **http://127.0.0.1:5000**

### 🖼️ Add Your Profile Image

1. Find a photo of yourself (square photo works best)
2. Rename it to `profile.jpg`
3. Copy it to: `static/images/profile.jpg`

Or use this command:
```powershell
Copy-Item "path\to\your\photo.jpg" "static\images\profile.jpg"
```

### 🚀 Running the App

**Start the server:**
```powershell
cd "c:\Users\Aryan Kota\Desktop\project 47\portfolio-flask"
venv\Scripts\activate
python app.py
```

Then open: **http://127.0.0.1:5000**

**Stop the server:**
Press `CTRL+C` in the terminal

### 📁 Project Structure

```
portfolio-flask/
├── app.py                    # Flask backend (Python)
├── templates/                # HTML pages
├── static/
│   ├── css/style.css        # All styling
│   ├── js/                  # JavaScript files
│   │   ├── hero-animation.js  # 3D animation
│   │   ├── projects.js        # Expandable projects
│   │   └── main.js            # Global JS
│   └── images/
│       ├── profile.jpg      # ⚠️ ADD YOUR PHOTO HERE
│       └── projects/
│           └── bridgegen/   # ✅ Screenshots already copied
```

### 🎨 Customization

**Change colors:**
Edit `static/css/style.css` lines 1-10 (CSS variables)

**Update content:**
Edit HTML files in `templates/` folder

**Modify 3D animation:**
Edit `static/js/hero-animation.js`

### 🌐 Pages Available

- Home: http://127.0.0.1:5000/
- About: http://127.0.0.1:5000/about
- Projects: http://127.0.0.1:5000/projects
- Skills: http://127.0.0.1:5000/skills
- Experience: http://127.0.0.1:5000/experience
- Contact: http://127.0.0.1:5000/contact

### ✨ Features Included

✅ 3D animated hero section with Three.js
✅ Responsive design (mobile-friendly)
✅ Expandable project cards
✅ Smooth animations
✅ Contact form
✅ All your personal content
✅ BridgeGen screenshots

### 📝 Next Steps

1. **Add your profile image** to `static/images/profile.jpg`
2. **Test all pages** by clicking navigation links
3. **Customize colors/styling** if needed
4. **Deploy to web hosting** when ready (see README.md)

### 🐛 Troubleshooting

**Images not loading?**
- Make sure you added `profile.jpg` to `static/images/`
- Check that BridgeGen screenshots are in `static/images/projects/bridgegen/`

**Port already in use?**
- Change port in `app.py`: `app.run(debug=True, port=5001)`

**3D animation not showing?**
- Check browser console for errors (F12)
- Make sure Three.js CDN is loading

### 📧 Questions?

Email: aryan@akitavault.com
