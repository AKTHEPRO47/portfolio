# Profile Image

Place your profile photo here as `profile.jpg`

Requirements:
- Filename: profile.jpg
- Recommended size: 400x400 pixels or larger (square)
- Format: JPG, PNG, or WebP
- The image will be displayed as a circular avatar on the homepage

If no image is provided, you can use a placeholder or the site will show a broken image icon.
